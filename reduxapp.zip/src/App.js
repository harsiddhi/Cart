import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter,Link,Route,Switch} from 'react-router-dom';
import Header from './Components/Header';



function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Header/>
        <Route path='/' exact>
          
        </Route>
      </BrowserRouter>
    </div>
  );
}

export default App;
