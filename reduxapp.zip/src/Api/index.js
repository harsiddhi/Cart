import axios from 'axios' ;
let api_url = '';
export default function callApi(endpoint,method='GET',body){
    return axios({
        method,
        url:`${api_url}/${endpoint}`,
        data:body
    }).catch(err=>{
        console.log(err)
    })
}