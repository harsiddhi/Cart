import React, { Component } from 'react'

export default class Cart extends Component {
    render() {
        return (
            <div>
                Cart Component.. 
            </div>
        )
    }
}
