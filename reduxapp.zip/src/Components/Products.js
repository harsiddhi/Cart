import React, { Component } from 'react'

export default class Products extends Component {
    render() {
        return (
            <div>
                Products Task... 
            </div>
        )
    }
}
